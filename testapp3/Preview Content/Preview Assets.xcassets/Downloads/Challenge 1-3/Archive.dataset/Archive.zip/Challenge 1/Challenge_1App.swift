//
//  Challenge_1App.swift
//  Challenge 1
//
//  Created by Sophie Lian on 25/5/25.
//

import SwiftUI

@main
struct Challenge_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
