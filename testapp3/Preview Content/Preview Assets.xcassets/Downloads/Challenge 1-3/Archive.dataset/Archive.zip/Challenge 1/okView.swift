//
//  okView.swift
//  Challenge 1
//
//  Created by Shivanishri on 3/6/25.
//

import SwiftUI

struct okView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    okView()
}
